﻿using UnityEngine;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using FuelReduxUtils;

namespace FuelSDKIntegration.Utils
{

	public class RemoteImages : Singleton<RemoteImages> {

		private const string img1 = "0e3b50863f9005e910d87dc182191805";
		private const string img2 = "2e708b8089fb0034e6631029e9ae89e0";
		private const string img3 = "e1667923e44e1b343ad4c89bbbb198df";

		private Sprite defaultTexture = new Sprite();
		private Dictionary<string, Sprite> resourcestextures = new Dictionary<string, Sprite>();
		private Dictionary<string, Sprite> textures = new Dictionary<string, Sprite>();


		void Awake(){
			// Cache textures from Resources
			Sprite data1 = new Sprite();
			data1 = Resources.Load( "Images/"+img1 ) as Sprite;
			resourcestextures.Add(img1, data1);

			Sprite data2 = new Sprite();
			data2 	= Resources.Load( "Images/"+img2 ) as Sprite;
			resourcestextures.Add(img2, data2);

			Sprite data3 = new Sprite();
			data3 = Resources.Load( "Images/"+img3 ) as Sprite;
			resourcestextures.Add(img3, data3);
		}

		private static bool addNewToCache(string md5, Sprite texture){
			Sprite data = new Sprite();
			data = texture;

			if(CachedTextures.ContainsKey(md5)){
				Debug.LogWarning(">>>RemoteImages.addNewToCache:: Trying to add an image already added");
				return false;
			}

			CachedTextures.Add(md5, data);
			return true;
		}

		public static Dictionary<string, Sprite> CachedTextures{
			get{ return Instance.textures; }
		}

		private static string getMD5(string url){
			return HashUtility.Md5Sum(url);
		}

		/*
		public static void ClearUnused(){
			List<string> toRemove = new List<string>();

			// Remove if Hit <= 0
			foreach(string key in CachedTextures.Keys)
				if(CachedTextures[key].second <= 0)
					toRemove.Add(key);

			// Remove
			for(int i=0; i<toRemove.Count; ++i){
				Destroy(CachedTextures[ toRemove[i] ].first);
				CachedTextures.Remove( toRemove[i] );
			}
			toRemove.Clear();
		}
		*/

		/*
		public static void RemoveFromCache(string url){
			// Null or empty URL
			if(string.IsNullOrEmpty(url)){
				//Log.Warning(">>>RemoteImages.RemoveFromCache:: Null or Empty URL");
			}
			
			string md5Url = getMD5(url);
			if(CachedTextures.ContainsKey(md5Url)){
				CachedTextures[md5Url].second -= 1;

	//			if(CachedTextures[md5Url].second <= 0){
	//				Destroy(CachedTextures[md5Url].first);
	//				CachedTextures.Remove(md5Url);
	//				Log.Warning(">>>RemoteImages.RemoveFromCache:: Remove {0} from cache", md5Url);
	//			}
			}

			if(instance.resourcestextures.ContainsKey(md5Url))
				return;

			//Log.Warning(">>>RemoteImages.RemoveFromCache:: Image {0} not in cache", md5Url);
		}
		*/

		public static System.Collections.IEnumerator CacheFromUrl( string url ) {

			Rect spriteRect;
			Vector2 spritePivot;

			// Null or empty URL
			if(string.IsNullOrEmpty(url)){
				Debug.LogWarning(">>>RemoteImages.CacheFromUrl:: Null or Empty URL");
				yield break;
			}

			string md5Url = getMD5(url);

			// STEP 1 - Check Resource Cache
			if(Instance.resourcestextures.ContainsKey(md5Url))
				yield break;

			// STEP 1 = Image is inside Primary Cache
			if(CachedTextures.ContainsKey(md5Url)){
				yield break;
			}

			// STEP 2 = Image is inside Secondary Cache
			bool isInCache = FileStorage.CheckAutoFile( md5Url );
			if(isInCache) {
				// Load if is in Cache
				WWW mywww = new WWW("file://"+FileStorage.GetBasePathAuto(md5Url));
				yield return mywww;

				if(!string.IsNullOrEmpty(mywww.error)){
					Debug.LogError(">>>RemoteImages.CacheFromUrl:: Error reading File Trying Download Again. Error="+mywww.error);
				}else{
					spriteRect = new Rect(0, 0, mywww.texture.width, mywww.texture.height);
					spritePivot = new Vector2(0.5f,0.5f);
					Sprite wwwTexture = Sprite.Create( mywww.texture, spriteRect, spritePivot);
					if(addNewToCache(md5Url, wwwTexture)){
						yield break;
					}else{
						// Image already exist
						Destroy(wwwTexture);
					}
				}
			}

			// STEP 3 = Image is From the server
			WWW serverwww = null;
			try{
				serverwww = new WWW(url);
			}catch(System.Exception e) {
				Debug.LogError(">>>RemoteImage.CacheFromUrl:: Exception Downloading Image. Error="+ e.ToString());
			}


			// Image is From the server - Error Downloading
			if(serverwww == null){
				Debug.LogError(">>>RemoteImage.CacheFromUrl:: Coudln't Download Image");
				yield break;
			}
			yield return serverwww;
			if(!string.IsNullOrEmpty(serverwww.error)){
				Debug.LogError(">>>RemoteImage.CacheFromUrl:: Coudln't Download Image. Error="+ serverwww.error);
				yield break;
			}
			if(serverwww.bytes == null || serverwww.bytes.Length <= 0){
				Debug.LogError(">>>RemoteImage.CacheFromUrl:: Image Size too small to be an Image");
				yield break;
			}

			if (isBogus (serverwww.texture)) {
				Debug.LogError(">>>RemoteImage.CacheFromUrl:: Image format is not PNG or JPG");
				yield break;
			}
			//TextureFormat format = serverwww.texture.EncodeToPNG;

			spriteRect = new Rect(0, 0, serverwww.texture.width, serverwww.texture.height);
			spritePivot = new Vector2(0.5f,0.5f);
			Sprite wwwServerTexture = Sprite.Create( serverwww.texture, spriteRect, spritePivot);

			if(addNewToCache(md5Url, wwwServerTexture)){
				FileStorage.WriteAutoFile(md5Url, serverwww.bytes);
				yield break;
			}else{
				// Image already exist
				Destroy(wwwServerTexture);
			}
		}

		public static Sprite GetFromCache ( string url ) {
			// Null or empty URL
			if(string.IsNullOrEmpty(url)){
				Debug.LogWarning(">>>RemoteImages.GetFromCache:: Null or Empty URL, Returning a 2x2 Texture");
				return Instance.defaultTexture;
			}

			string md5Url = getMD5(url);
			// Check Resource Cache
			if(Instance.resourcestextures.ContainsKey(md5Url))
				return Instance.resourcestextures[md5Url];

			// Check Normal Cache
			if(CachedTextures.ContainsKey(md5Url)){
				return CachedTextures[md5Url];
			}

			Debug.LogWarning(">>>RemoteImage.GetFromCache:: "+url+"{0} : Returning a 2x2 Texture" );
			return Instance.defaultTexture;
		}

		public static void SetDefaultImage(Sprite defaultImage){
			Instance.defaultTexture = defaultImage;
		}

		// check if the image loaded is the question mark default error image
		public static bool isBogus(Texture tex) {
			if (!tex) return true;
			
			byte[] png1 = (tex as Texture2D).EncodeToPNG();
			byte[] questionMarkPNG = new byte[] {137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,8,0,0,0,8,8,2,0,0,0,75,109,41,220,0,0,0,65,73,68,65,84,8,29,85,142,81,10,0,48,8,66,107,236,254,87,110,106,35,172,143,74,243,65,89,85,129,202,100,239,146,115,184,183,11,109,33,29,126,114,141,75,213,65,44,131,70,24,97,46,50,34,72,25,39,181,9,251,205,14,10,78,123,43,35,17,17,228,109,164,219,0,0,0,0,73,69,78,68,174,66,96,130,};
			
			return Equivalent(png1, questionMarkPNG);
		}
		// compare bits betwen images
		public static bool Equivalent(byte[] bytes1, byte[] bytes2) {
			if (bytes1.Length != bytes2.Length) return false;
			for (int i=0;i<bytes1.Length;i++)
				if (!bytes1[i].Equals(bytes2[i])) return false;
			return true;
		}
	}
}