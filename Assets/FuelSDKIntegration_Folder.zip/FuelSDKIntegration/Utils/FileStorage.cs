﻿using UnityEngine;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;

namespace FuelSDKIntegration.Utils
{

	public class FileStorage{
		
		//********************
		// Properties
		//********************
		private string contentPath;
		public static string Unknown 				{ 	get { return "etc"; } }
		public static string Images					{ 	get { return "images"; } }
		public static string Videos					{ 	get { return "videos"; } }
		public static string Music					{ 	get { return "music"; } }
		public static string Data 					{ 	get { return "data"; } }
		
		//********************
		// File Types
		//********************
		public enum FileType{
			Unknown,
			Image,
			Video,
			Music,
			Data
		}
		
		//********************
		// Singleton Instance
		//********************
		#region Singleton
		private static FileStorage _instance;
		
		private static FileStorage instance{
			get {
				Instantiate();
				return _instance;
			}
		}
		
		public static void Instantiate(){
			if(_instance == null) _instance = new FileStorage();
		}
		
		private FileStorage(){
			contentPath 		= Application.temporaryCachePath;
			
			Debug.Log(">>>FileStorage: Application.dataPath				="+Application.dataPath);
			Debug.Log(">>>FileStorage: Application.streamingAssetsPath	="+Application.streamingAssetsPath);
			Debug.Log(">>>FileStorage: Application.persistentDataPath	="+Application.persistentDataPath);
			Debug.Log(">>>FileStorage: Application.temporaryCachePath	="+Application.temporaryCachePath);
			
			CreateDirectory(contentPath +"/"+Images );
			CreateDirectory(contentPath +"/"+Videos);
			CreateDirectory(contentPath +"/"+Music);
			CreateDirectory(contentPath +"/"+Data);
			CreateDirectory(contentPath +"/"+Unknown , true);
		}
		#endregion
		
		#region Path Helpers
		/// <summary>
		/// Gets the base path concatenated with the Auto path.
		/// </summary>
		/// <returns>
		/// Full path where the file might be located.
		/// </returns>
		/// <param name='file'>
		/// File to look up for.
		/// </param>
		public static string GetBasePathAuto(string file){
			return GetBasePath( GetAutoPath(file) );
		}
		
		/// <summary>
		/// Gets a path where the file might be stored acoording to the file extension. The path is relative to the base path.
		/// </summary>
		/// <returns>
		/// Path where the file might be located.
		/// </returns>
		/// <param name='file'>
		/// File to look up for.
		/// </param>
		public static string GetAutoPath(string file){
			FileType type = GetFileType(file);
			return 	MapFileExtension(type) + "/" +file;
		}
		
		/// <summary>
		/// Get a string representing the Base game path with the file path.
		/// </summary>
		/// <returns>
		/// The base path.
		/// </returns>
		/// <param name='file'>
		/// File.
		/// </param>
		public static string GetBasePath(string file){
			return instance.contentPath + "/" + file;
		}
		#endregion
		
		//********************
		// Check Path Stuff
		//********************
		#region Check Stuff
		
		/// <summary>
		/// Checks if the folder exist inside the base directory.
		/// </summary>
		/// <returns>
		/// <c>True</c> if the Folder exists. <c>False</c> otherwise.
		/// </returns>
		/// <param name='dirname'>
		/// Folder name.
		/// </param>
		public static bool CheckBaseDirectory(string dirname){
			return CheckDirectory( GetBasePath(dirname) );
		}
		
		/// <summary>
		/// Checks if the folder exist.
		/// </summary>
		/// <returns>
		/// <c>True</c> if the Folder exists. <c>False</c> otherwise.
		/// </returns>
		/// <param name='dirname'>
		/// Full Path Folder name.
		/// </param>
		public static bool CheckDirectory(string dirname){
			return Directory.Exists( dirname );
		}
		
		/// <summary>
		/// Wraps Directory.GetFiles function.
		/// Returns the names of files (including their paths) that match the specified search pattern in the specified directory.
		/// </summary>
		/// <returns>An array of the full names (including paths) for the files in the specified directory that match the specified search pattern, or an empty array if no files are found.</returns>
		/// <param name="dirpath">The relative or absolute path to the directory to search. This string is not case-sensitive.</param>
		/// <param name="searchPattern">The search string to match against the names of files in path.</param>
		public static string[] GetFilenames(string dirpath, string searchPattern){
			if(Directory.Exists(dirpath))
				return Directory.GetFiles(dirpath, searchPattern);
			
			return null;
		}
		
		//********************
		// Check File
		
		/// <summary>
		/// Checks if the File exist into the corresponding folder inside the base path acoording to it's file extension.
		/// </summary>
		/// <returns>
		/// <c>True</c> if the file exists. <c>False</c> otherwise.
		/// </returns>
		/// <param name='filename'>
		/// Filename to check
		/// </param>
		public static bool CheckAutoFile(string filename){
			return CheckBaseFile( GetAutoPath(filename) );
		}
		
		/// <summary>
		/// Checks if the File exist inside the base path.
		/// </summary>
		/// <returns>
		/// <c>True</c> if the file exists. <c>False</c> otherwise.
		/// </returns>
		/// <param name='filename'>
		/// Base Path relative Filename to check
		/// </param>
		public static bool CheckBaseFile(string filename){
			return CheckFile( GetBasePath(filename) );
		}
		
		/// <summary>
		/// Checks if the File exist.
		/// </summary>
		/// <returns>
		/// <c>True</c> if the file exists. <c>False</c> otherwise.
		/// </returns>
		/// <param name='filename'>
		/// Full path Filename to check
		/// </param>
		public static bool CheckFile(string filePath){
			Debug.Log(">>>FileStorage.CheckFile: path="+filePath);
			
			if(string.IsNullOrEmpty(filePath)){
				Debug.LogWarning(">>>FileStorage.CheckFile: Path is null or empty");
				return false;
			}
			
			bool exist = false;
			// Hard Check File
			try{
				exist = File.Exists(filePath);
			}catch(Exception e){
				Debug.LogError(">>>FileStorage.CheckPath: Exception:"+e.Message);
			}
			
			return exist;
		}
		
		public static int CheckDateFile(string filename, DateTime reference){
			if( CheckFile(filename) ){
				DateTime creationTime = File.GetCreationTimeUtc( GetBasePath(filename) );
				return creationTime.CompareTo( reference );
			}
			
			return -1;
		}
		#endregion
		
		//********************
		// Create Stuff
		//********************
		#region Create Stuff
		/// <summary>
		/// Creates the directory relative to the Base path.
		/// </summary>
		/// <returns>
		/// <c>True</c> if the directory was created successfully, <c>False</c> otherwise
		/// </returns>
		/// <param name='dirname'>
		/// Folder name.
		/// </param>
		public static bool CreateBaseDirectory(string dirname){
			if(CheckBaseDirectory(dirname)) return true;
			
			return CreateDirectory( GetBasePath(dirname) );
		}
		
		/// <summary>
		/// Creates the directory based on the full path.
		/// </summary>
		/// <returns>
		/// c>True</c> if the directory was created successfully, <c>False</c> otherwise
		/// </returns>
		/// <param name='path'>
		/// FullPath Foldername.
		/// </param>
		public static bool CreateDirectory( string path , bool forceCreation = false ){
			if( Directory.Exists( path ) ) {
				if( forceCreation ) {
					Directory.Delete( path , true );
				}
				else {
					return true;
				}
			}
			
			try{
				Directory.CreateDirectory(path);
				return true;
			}catch(IOException e){
				Debug.LogError(">>>FileStorage.CreateDirectory: IO Error:"+e.Message);
			}
			return false;
		}
		
		//********************
		// Write Binary
		
		/// <summary>
		/// Write into the cooresponding folder based on the file extension relative to the Base path all the data as a binary file.
		/// </summary>
		/// <returns>
		/// True if the write was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// Filename with extension.
		/// </param>
		/// <param name='data'>
		/// All binary data to write.
		/// </param>
		public static bool WriteAutoFile(string path, byte[] data){
			return 	WriteBase( GetAutoPath(path), data);
		}
		
		/// <summary>
		/// Write into the specified path relative to the Base path all the data as a binary file.
		/// </summary>
		/// <returns>
		/// True if the write was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// The Base Relative path where to write the data.
		/// </param>
		/// <param name='data'>
		/// All binary data to write.
		/// </param>
		public static bool WriteBase(string path, byte[] data){
			return Write(GetBasePath(path), data);
		}
		
		/// <summary>
		/// Write into the specified path all the data as a binary file.
		/// </summary>
		/// <returns>
		/// True if the write was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// The full path where to write the data.
		/// </param>
		/// <param name='data'>
		/// All binary data to write.
		/// </param>
		public static bool Write(string path, byte[] data){
			Debug.Log(">>>FileStorage.Write: path="+path);
			
			if(!checkConsistencyFile(path))
				return false;
			
			try{
				FileStream stream = new FileStream( path, FileMode.Create);
				BinaryWriter writer = new BinaryWriter(stream);
				
				writer.Write(data);
				writer.Close();
				return true;
			}
			catch(IOException e){
				Debug.LogError(">>>FileStorage.Write: IO Error:"+e.Message);
			}
			catch(Exception e){
				Debug.LogError(">>>FileStorage.Write: Error:"+e.Message);
			}
			return false;
		}
		
		//********************
		// Write Text
		
		/// <summary>
		/// Write into the cooresponding folder based on the file extension relative to the Base path all the plain text data.
		/// </summary>
		/// <returns>
		/// True if the write was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// Filename with extension.
		/// </param>
		/// <param name='data'>
		/// All plain text data to write.
		/// </param>
		public static bool WriteAutoFile(string path, string data){
			return 	WriteBase( GetAutoPath(path), data);
		}
		
		/// <summary>
		/// Write into the specified path relative to the Base path all the plain text data.
		/// </summary>
		/// <returns>
		/// True if the write was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// TThe Base Relative path where to write the data.
		/// </param>
		/// <param name='data'>
		/// All plain text data to write.
		/// </param>
		public static bool WriteBase(string path, string data){
			return 	Write( GetBasePath(path), data);
		}
		
		/// <summary>
		/// Write into the specified path all the plain text data.
		/// </summary>
		/// <returns>
		/// True if the write was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// The full path where to write the data.
		/// </param>
		/// <param name='data'>
		/// All plain text data to write.
		/// </param>
		public static bool Write(string path, string data){
			Debug.Log(">>>FileStorage.Write: path="+path);
			
			if(!checkConsistencyFile(path))
				return false;
			
			try{
				File.WriteAllText( path, data);
				return true;
			}catch(IOException e){
				Debug.LogError(">>>FileStorage.Write: IO Exception:"+e.Message);
			}
			catch(Exception e){
				Debug.LogError(">>>FileStorage.Write: Exception:"+e.Message);
			}
			
			return false;
		}
		
		//********************
		// Append Text
		
		/// <summary>
		/// Append text into the cooresponding file based on the file extension.
		/// </summary>
		/// <returns>
		/// True if the append was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// Filename with extension.
		/// </param>
		/// <param name='data'>
		/// Plain text data to write.
		/// </param>
		public static bool AppendAutoFile(string path, string data){
			return 	AppendBase( GetAutoPath(path), data);
		}
		
		/// <summary>
		/// Append text to the specified Base relative data path file.
		/// </summary>
		/// <returns>
		/// True if the append was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// Base Relative path of the file where to append the text.
		/// </param>
		/// <param name='data'>
		/// Plain text data to write.
		/// </param>
		public static bool AppendBase(string path, string data){
			return 	Append( GetBasePath(path), data);
		}
		
		/// <summary>
		/// Append text to the specified full path data file.
		/// </summary>
		/// <returns>
		/// True if the append was sucess, false otherwise.
		/// </returns>
		/// <param name='path'>
		/// The full path of the file where to append the text.
		/// </param>
		/// <param name='data'>
		/// Plain text data to write.
		/// </param>
		public static bool Append(string path, string data){
			Debug.Log(">>>FileStorage.Append: path="+path);
			
			if(!checkConsistencyFile(path))
				return false;
			
			if( CheckFile(path) ){
				try{
					StreamWriter writer = File.AppendText( path );
					writer.WriteLine(data);
					writer.Close();
					writer.Dispose();	
					return true;
				}catch(IOException e){
					Debug.LogError(">>>FileStorage.Append: IO Exception:"+e.Message);
				}
				catch(Exception e){
					Debug.LogError(">>>FileStorage.Append: Exception:"+e.Message);
				}
			}else{
				return Write(path, data);
			}
			
			return false;
		}
		#endregion
		
		#region Delete
		/// <summary>
		/// Deletes the file inside the cooresponding folder based on the file extension relative to the Base path.
		/// </summary>
		/// <returns><c>true</c>, if file auto was deleted, <c>false</c> otherwise.</returns>
		/// <param name="path">Context Path.</param>
		public static bool DeleteFileAuto(string path){
			return 	DeleteFileBase( GetAutoPath(path) );
		}
		
		/// <summary>
		/// Deletes the file relative to the base path.
		/// </summary>
		/// <returns><c>true</c>, if file base was deleted, <c>false</c> otherwise.</returns>
		/// <param name="path">Relative Path.</param>
		public static bool DeleteFileBase(string path){
			return 	DeleteFile( GetBasePath(path) );
		}
		
		/// <summary>
		/// Deletes the file with the given full path.
		/// </summary>
		/// <returns><c>true</c>, if file was deleted, <c>false</c> otherwise.</returns>
		/// <param name="path">Full Path.</param>
		public static bool DeleteFile(string path){
			Debug.Log(">>>FileStorage.DeleteFile: path="+path);
			
			if(!CheckFile(path))
				return true;
			
			try{
				File.Delete(path);
				return true;
			}catch(IOException e){
				Debug.LogError(">>>FileStorage.Write: IO Exception:"+e.Message);
			}
			catch(Exception e){
				Debug.LogError(">>>FileStorage.Write: Exception:"+e.Message);
			}
			
			return false;
		}
		#endregion
		
		//********************
		// Read Stuff
		//********************
		#region Read Stuff
		/// <summary>
		/// Reads a file relative to a base path and acoording to it file extension as a string.
		/// </summary>
		/// <returns>
		/// String containing file data.
		/// </returns>
		/// <param name='path'>
		/// File path relative to the base path and acoording to it file extension.
		/// </param>
		public static string ReadAutoString(string path){
			return ReadBaseString( GetAutoPath(path) );
		}
		
		/// <summary>
		/// Reads a file relative to a base path as a string.
		/// </summary>
		/// <returns>
		/// String containing file data.
		/// </returns>
		/// <param name='path'>
		/// File path relative to the base path.
		/// </param>
		public static string ReadBaseString(string path){
			return ReadString( GetBasePath(path) );
		}
		
		/// <summary>
		/// Reads a file as a string.
		/// </summary>
		/// <returns>
		/// String containing file data.
		/// </returns>
		/// <param name='fullPath'>
		/// Full file path.
		/// </param>
		public static string ReadString(string fullPath){
			Debug.Log(">>>FileStorage.ReadString: path="+fullPath);
			
			if(CheckFile(fullPath)){
				try{
					string fileData = File.ReadAllText(fullPath);
					return fileData;
				}
				catch(IOException e){
					Debug.LogError(">>>FileStorage.ReadString: IO Error:"+e.Message);
				}
				catch(Exception e){
					Debug.LogError(">>>FileStorage.ReadString: Error:"+e.Message);
				}	
			}else{
				Debug.LogError(">>>FileStorage.ReadString: No Existing File="+fullPath);
			}
			return null;
		}
		
		/// <summary>
		/// Reads a file relative to a base path and acoording to it file extension as a byte array.
		/// </summary>
		/// <returns>
		/// The byte array.
		/// </returns>
		/// <param name='fullPath'>
		/// File path relative to the base path and acoording to it file extension.
		/// </param>
		public static byte[] ReadAutoBytes(string path){
			return ReadBaseBytes( GetAutoPath(path) );
		}
		
		/// <summary>
		/// Reads a file relative to a base path as a byte array.
		/// </summary>
		/// <returns>
		/// The byte array.
		/// </returns>
		/// <param name='fullPath'>
		/// File path relative to the base path.
		/// </param>
		public static byte[] ReadBaseBytes(string path){
			return ReadBytes( GetBasePath(path) );
		}
		
		/// <summary>
		/// Reads a file as a byte array.
		/// </summary>
		/// <returns>
		/// The byte array.
		/// </returns>
		/// <param name='fullPath'>
		/// File Full path.
		/// </param>
		public static byte[] ReadBytes(string fullPath){
			Debug.Log(">>>FileStorage.ReadBytes: path="+fullPath);
			
			byte[] fileData = null;
			if(CheckFile(fullPath)){
				try{
					fileData = File.ReadAllBytes(fullPath);
					return fileData;
				}
				catch(IOException e){
					Debug.LogError(">>>FileStorage.ReadBytes: IO Error:"+e.Message);
				}
				catch(Exception e){
					Debug.LogError(">>>FileStorage.ReadBytes: Error:"+e.Message);
				}	
			}else{
				Debug.LogError(">>>FileStorage.ReadBytes: No Existing File="+fullPath);
			}
			return fileData;
		}
		#endregion
		
		//********************
		// Helpers Stuff
		//********************
		#region Helpers
		/// <summary>
		/// Maps the file extension to a folder relative to the base path.
		/// </summary>
		/// <returns>
		/// Cooresponding folder name.
		/// </returns>
		/// <param name='type'>
		/// FileType.
		/// </param>
		private static string MapFileExtension(FileType type){
			switch(type){
			case FileType.Image:
				return Images;
			case FileType.Video:
				return Videos;
			case FileType.Music:
				return Music;
			case FileType.Data:
				return Data;
			default:
				return Unknown;
			}
		}
		
		/// <summary>
		/// Checks the consistency of the filepath.
		/// </summary>
		/// <returns>
		/// The consistency  of the file. <c>True</c> if the path is consistant.
		/// </returns>
		/// <param name='filepath'>
		/// Full filepath.
		/// </param>
		private static bool checkConsistencyFile(string filepath){
			// Check file empty
			if(string.IsNullOrEmpty(filepath)){
				Debug.LogWarning(">>>FileStorage.CheckConsistencyFile: Path is null or empty");
				return false;
			}
			
			// Check Path
			string folder = GetFolderPath(filepath);
			if( !string.IsNullOrEmpty(folder) && !CheckDirectory(folder)){
				return CreateDirectory(folder);
			}
			
			return true;
		}
		
		/// <summary>
		/// Gets the filename from a path.
		/// </summary>
		/// <returns>
		/// The filename.
		/// </returns>
		/// <param name='filepath'>
		/// Filepath of the file.
		/// </param>
		public static string GetFilename(string filepath){
			int lastIndex = filepath.LastIndexOf("/");
			if(lastIndex > 0)
				return filepath.Substring(lastIndex+1);
			else
				return filepath;
		}
		
		/// <summary>
		/// Gets the folder path, i.e. the pafh without the filename.
		/// </summary>
		/// <returns>
		/// The folder path.
		/// </returns>
		/// <param name='filepath'>
		/// Full path filename.
		/// </param>
		public static string GetFolderPath(string filepath){
			int lastIndex = filepath.LastIndexOf("/");
			if(lastIndex > 0)
				return filepath.Substring(0, lastIndex+1);
			else
				return "";
		}
		
		/// <summary>
		/// Gets the file extension of a filename.
		/// </summary>
		/// <returns>
		/// The file extension.
		/// </returns>
		/// <param name='filepath'>
		/// Filepath.
		/// </param>
		public static string GetFileExtension(string filepath){
			string filename = GetFilename(filepath);
			int lastIndex = filename.IndexOf('.');
			
			if(lastIndex > 0)
				return filename.Substring( lastIndex+1 ).ToLower();
			else
				return "";
		}
		
		/// <summary>
		/// Gets the type of the file acoording to it's file extension.
		/// </summary>
		/// <returns>
		/// The file type.
		/// </returns>
		/// <param name='filepath'>
		/// Filane name or full path.
		/// </param>
		public static FileType GetFileType(string filepath){
			string ext = GetFileExtension(filepath);
			
			switch(ext.ToLower()){
			case "png": case "jpg": case "bmp": case "jpeg": case "gif": 
				return FileType.Image;
				
			case "mp3": case "ogg": case "wav":
				return FileType.Music;
				
			case "mp4": case "avi": case "3gp":
				return FileType.Video;
				
			case "sql": case "txt": case "json": case "log":
				return FileType.Data;
				
			default:
				return FileType.Unknown;
			}
		}
		#endregion
	}

}