﻿using UnityEngine;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using FuelReduxUtils;

public static class DebugManager {

	#region ===================================== USER DATA DEBUG =====================================

	[CUDLR.Command("ResetData", "Reset the user data.")]
	public static void ResetData() {
		//UserProfileManager.Instance.DebugResetData ();
		//UserProfileManager.Instance.DebugSaveUserData();
	}

	[CUDLR.Command("AddCoins", "Add coins to the user data. Params: coins")]
	public static void AddCoins( string[] cudlrParams )
	{
		if (cudlrParams.Length != 1)
		{
			Debug.Log("Error: You need to specify a coins value for call the AddCoins method.");
		}

		//UserProfileManager.Instance.AddCoins( Convert.ToInt32(cudlrParams[0]) );
		//UserProfileManager.Instance.DebugSaveUserData();
	}


	#endregion
}
