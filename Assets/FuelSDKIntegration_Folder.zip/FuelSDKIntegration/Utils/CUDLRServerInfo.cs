using UnityEngine;
using System.Net;
using System.Net.Sockets;

// prints current IP address on screen, pulling port from CUDLR
public class CUDLRServerInfo : MonoBehaviour
{
    //////////////////////////////////////////////////

    [SerializeField] float m_uiLeftBorder = 5f;
    [SerializeField] float m_uiBottomBorder = 25f;
    [SerializeField] float m_uiWidth = 200f;
    [SerializeField] float m_uiHeight = 25f;
    string m_ipAddress;

    //////////////////////////////////////////////////

	void Awake()
	{
		DontDestroyOnLoad(gameObject);
	}

    void Start()
    {
        m_ipAddress = Network.player.ipAddress;
        
        var cudlrServer = GetComponent<CUDLR.Server>();
        if (cudlrServer != null)
        {
            m_ipAddress += ":" + cudlrServer.Port;
        }

        m_ipAddress = "Console: http://" + m_ipAddress;
    }

    void OnGUI()
    {
        var ipLabelRect = new Rect(m_uiLeftBorder, Screen.height - m_uiBottomBorder,
                                   m_uiWidth, m_uiHeight);

		GUIStyle style = new GUIStyle();
		style.normal.textColor = Color.black;

		GUI.Label(ipLabelRect, m_ipAddress, style);
    }
}