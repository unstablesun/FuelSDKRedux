﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace FuelSDKIntegration.Structures 
{	
	public class IgniteNotice 
	{
		public string Id { get; set; }
		public NoticeMetadata Metadata { get; set; }

		private string message;
		public string Message { 
			get {
				return  message;
			}
		}

		public IgniteNotice() {
			this.Id = "";
			this.message = "";
			this.Metadata = new NoticeMetadata();
		}

		public void Create ( Dictionary<string,object> noticeDict ) {
			if( noticeDict.ContainsKey( "id" ) ) {
				this.Id = Convert.ToString( noticeDict["id"] );
			}

			if( noticeDict.ContainsKey( "message" ) ) {
				this.message = Convert.ToString( noticeDict["message"] );
			}

			if( noticeDict.ContainsKey( "metadata" ) ) {
				Dictionary<string,object> noticeMetadataDict = noticeDict["metadata"] as Dictionary<string,object>;
				NoticeMetadata noticeMetada = new NoticeMetadata();

				if( noticeMetadataDict.ContainsKey( "title" ) ) {
					noticeMetada.title = Convert.ToString( noticeMetadataDict["title"] );
				}
					
				if( noticeMetadataDict.ContainsKey( "virtualGood" ) ) {
					Dictionary<string,object> virtualGoodDict = noticeMetadataDict["virtualGood"] as Dictionary<string,object>;
					noticeMetada.VirtualGood = VirtualGoodData.ParseFromDictionary( virtualGoodDict );
				}

				this.Metadata = noticeMetada;
			}
		}

		public bool HaveVirtualGood {
			get {
				if( this.Metadata == null ) {
					return false;
				}
				return ( !string.IsNullOrEmpty( this.Metadata.VirtualGood.Id ) );
			}
		}
	}

	public class NoticeMetadata 
	{
		public string title;
		public string Title { 
			get {
				return title;
			}
		}

		public VirtualGoodData VirtualGood { get; set; }

		public NoticeMetadata() {
			this.title = "";
			this.VirtualGood = new VirtualGoodData();
		}
	}

}
