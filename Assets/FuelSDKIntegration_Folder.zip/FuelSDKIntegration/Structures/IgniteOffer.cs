﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

namespace FuelSDKIntegration.Structures 
{
	public class IgniteOffer : IgniteActivity 
	{
		public bool Accepted;
		public bool Acceptable;
		public OfferMetadata Metadata { get; set; }
		public OfferVisualData VisualData { get; set; }

		public IgniteOffer() {
			this.Metadata = new OfferMetadata();
			this.VisualData = new OfferVisualData( string.Empty );
		}

		public override void Create( Dictionary<string,object> dataDict ) {
			base.Create( dataDict );
			if( dataDict.ContainsKey( "accepted" ) ) {
				this.Accepted = Convert.ToBoolean( dataDict["accepted"] );
			}
			if( dataDict.ContainsKey( "acceptable" ) ) {
				this.Acceptable = Convert.ToBoolean( dataDict["acceptable"] );
			}
			if( dataDict.ContainsKey( "metadata" ) ) {
				Dictionary<string,object> missionMetadataDict = dataDict["metadata"] as Dictionary<string,object>;
				this.Metadata = new OfferMetadata();
				this.Metadata.Create( missionMetadataDict );
			}
			this.VisualData = new OfferVisualData( this.Id );
		}
	}
		
	public class OfferMetadata:IgniteActivityMetadata  
	{
		public enum TransactionType
		{
			none         				= 0,
			coins_gained_gameplay 		= 1,
			coins_spent_unlockpirate    = 2
		}

		public string imageUrl { get; set; }
		public string ImageUrl { 
			get {
				if( !imageUrl.Contains("http:") ) {
					return "http:"+imageUrl;
				}
				return imageUrl;
			}
		}

		public TransactionType Transaction;

		public OfferMetadata() {
		}

		public override void Create ( Dictionary<string,object> metadataDict ) {
			base.Create( metadataDict );

			if( metadataDict.ContainsKey( "imageUrl" ) ) {
				this.imageUrl = Convert.ToString( metadataDict["imageUrl"] );
			}

			if( metadataDict.ContainsKey( "transaction" ) ) {
				this.Transaction = (TransactionType) Enum.Parse( typeof(TransactionType) , Convert.ToString( metadataDict["transaction"] ) );
			}
		}
	}

	public class OfferVisualData : VisualData
	{
		public OfferVisualData( string id ) : base ( id ) {
		}

		private const string prefHaveShowActiveNotice = "IgniteOfferHaveShowActiveNotice_";
		public bool HaveShowActiveNotice { 
			get {
				return base.GetBoolValue( prefHaveShowActiveNotice );
			}
			set {
				base.SetBoolValue( prefHaveShowActiveNotice, value );
			}
		}

		private const string prefHaveShowCommingSoonNotice = "IgniteOfferHaveShowCommingSooNotice_";
		public bool HaveShowCommingSoonNotice { 
			get {
				return base.GetBoolValue( prefHaveShowCommingSoonNotice );
			}
			set {
				base.SetBoolValue( prefHaveShowCommingSoonNotice, value );
			}
		}
	}

}
