using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FuelSDKIntegration.Structures 
{
	public class IgniteMission : IgniteActivity 
	{
		public Dictionary<string,MissionRuleData> Rules { get; set; }
		public MissionMetadata Metadata { get; set; }
		public MissionVisualData VisualData { get; set; }

		public IgniteMission() {
			this.Rules = new Dictionary<string, MissionRuleData>();
			this.Metadata = new MissionMetadata();
			this.VisualData = new MissionVisualData( string.Empty );
		}

		public bool AllRulesCompleted {
			get {
				return RulesCompleted == Rules.Count;
			}
		}

		public int RulesCompleted {
			get {
				int rulesCompleted = 0;
				if( Rules != null ) {
					foreach( MissionRuleData missionRule in Rules.Values ) {
						if( missionRule.Progress >= 1 ) {
							rulesCompleted++;
						}
					}
				}
				return rulesCompleted;
			}
		}

		public override void Create( Dictionary<string,object> dataDict ) {
			base.Create( dataDict );

			if( dataDict.ContainsKey( "metadata" ) ) {
				Dictionary<string,object> missionMetadataDict = dataDict["metadata"] as Dictionary<string,object>;
				this.Metadata = new MissionMetadata();
				this.Metadata.Create( missionMetadataDict );
			}
			if( dataDict.ContainsKey("rules") ) {
				this.Rules = new Dictionary<string, MissionRuleData>();
				List<object> rulesList = dataDict["rules"] as List<object>;
				foreach(object rule in rulesList ) {
					Dictionary<string,object> ruleDict = rule as Dictionary<string, object>;
					MissionRuleData ruleData = MissionRuleData.ParseFromDictionary( ruleDict );
					this.Rules.Add( ruleData.Id, ruleData);
				}
			}
			this.VisualData = new MissionVisualData( this.Id );
		}

		public override bool GetVirtualGood () {
			if( !string.IsNullOrEmpty( this.Metadata.VirtualGood.Id ) ) {
				this.Metadata.VirtualGood.GetReward();
				return true;
			}
			return base.GetVirtualGood();
		}

		public override bool HaveVirtualGood () {
			if( !string.IsNullOrEmpty( this.Metadata.VirtualGood.Id ) ) {
				return true;
			}
			return base.HaveVirtualGood();
		}

		public override bool Completed()  {
			return base.Progress >= 1;
		}
	}

	public class MissionMetadata:IgniteActivityMetadata 
	{
		public string GameData { get; set; }

		public MissionMetadata() {
		}

		public override void Create ( Dictionary<string,object> metadataDict ) {
			base.Create( metadataDict );

			if( metadataDict.ContainsKey( "gamedata" ) ) {
				this.GameData = Convert.ToString( metadataDict["gamedata"] );
			}
		}
	}

	public class MissionVisualData : VisualData 
	{
		public MissionVisualData( string id ) : base ( id ) {
		}

		private const string prefProgressValue = "IgniteMissionProgressValue_";
		public float ProgressValue { 
			get {
				return base.GetFloatValue( prefProgressValue );
			}
			set {
				base.SetFloatValue( prefProgressValue, value );
			}
		}

		private const string prefLastShowProgress = "IgniteMissionLastShowProgress_";
		public float LastShowProgress { 
			get {
				return base.GetFloatValue( prefLastShowProgress );
			}
			set {
				base.SetFloatValue( prefLastShowProgress, value );
			}
		}

		private const string prefCompleteCount = "IgniteMissionCompleteCount_";
		public int MissionCompleteCount { 
			get {
				return base.GetIntValue( prefCompleteCount );
			}
			set {
				base.SetIntValue( prefCompleteCount, value );
			}
		}
	}

	public enum MissionRuleType 
	{
		incremental = 0,
		spot       	= 1,
	}

	public struct MissionRuleData 
	{
		public string Id { get; set; }
		public int Score { get; set; }
		public int Target { get; set; }
		public bool Achieved { get; set; }
		public string Variable { get; set; }
		public MissionRuleType Kind { get; set; }
		public MissionRuleMetadata Metadata { get; set; }
		public MissionRuleVisualData VisualData { get; set; }

		public float Progress {
			get {
				double progressValue = (Target > 0)?Math.Round( (double)Score/(double)Target , 3 ):0;
				if( progressValue > 1 ) {
					progressValue = 1;
				}
				return (float)progressValue;
			}
		}

		public bool Complete {
			get {
				return Progress == 1.0f;
			}
		}

		public static MissionRuleData ParseFromDictionary ( Dictionary<string,object> ruleDict ) {
			MissionRuleData ruleData = new MissionRuleData();
			if( ruleDict.ContainsKey("id") ) {
				ruleData.Id = Convert.ToString( ruleDict["id"] );
			}
			if( ruleDict.ContainsKey("score") ) {
				ruleData.Score = Convert.ToInt32( ruleDict["score"] );
			}
			if( ruleDict.ContainsKey("target") ) {
				ruleData.Target = Convert.ToInt32( ruleDict["target"] );
			}
			if( ruleDict.ContainsKey("achieved") ) {
				ruleData.Achieved = Convert.ToBoolean( ruleDict["achieved"] );
			}
			if( ruleDict.ContainsKey("variable") ) {
				ruleData.Variable = Convert.ToString( ruleDict["variable"] );
			}
			if( ruleDict.ContainsKey("kind") ) {
				ruleData.Kind = (MissionRuleType) Enum.Parse( typeof(MissionRuleType) , Convert.ToString( ruleDict["kind"] ) );
			}
			if( ruleDict.ContainsKey( "metadata" ) ) {
				Dictionary<string,object> ruleMetadataDict = ruleDict["metadata"] as Dictionary<string,object>;
				ruleData.Metadata = new MissionRuleMetadata();
				ruleData.Metadata.Create( ruleMetadataDict );
			}
			ruleData.VisualData = new MissionRuleVisualData( ruleData.Id );
			return ruleData;
		}
	}

	public class MissionRuleMetadata:Metadata {
		
		public string GameData { get; set; } 

		public override void Create ( Dictionary<string,object> metadataDict ) {
			base.Create( metadataDict );

			if( metadataDict.ContainsKey( "gamedata" ) ) {
				this.GameData = Convert.ToString( metadataDict["gamedata"] );
			}

		}
	}

	public class MissionRuleVisualData : VisualData 
	{
		public MissionRuleVisualData( string id ) : base ( id ) {
		}

		private const string prefProgressValue = "IgniteMissionRuleProgressValue_";
		public float progressValue { 
			get {
				return base.GetFloatValue( prefProgressValue );
			}
			set {
				base.SetFloatValue( prefProgressValue, value );
			}
		}

		private const string prefLastShowProgress = "IgniteMissionRuleLastShowProgress_";
		public float lastShowProgress { 
			get {
				return base.GetFloatValue( prefLastShowProgress );
			}
			set {
				base.SetFloatValue( prefLastShowProgress, value );
			}
		}
	}

}
