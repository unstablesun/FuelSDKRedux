using UnityEngine;
using System;
using System.Collections.Generic;
using FuelReduxUtils;
using FuelSDKIntegration.Utils;

namespace FuelSDKIntegration.Structures 
{
	public class VirtualGoodData 
	{
		public enum RewardType {
			None = 0,
			Coins = 1
		}
		
		public string Id { get; set; }
		public RewardType Type { get; set; }
		public string GoodId { get; set; }
		public string Description { get; set; }
		public string iconUrl { get; set; }
		public string IconUrl { 
			get {
				if( !iconUrl.Contains("http:") ) {
					return "http:"+iconUrl;
				}
				return iconUrl;
			}
		}
		
		public string virtualGoodUrlIcon { get; set; }
		public string VirtualGoodUrlIcon { 
			get {
				if( !virtualGoodUrlIcon.Contains("http:") ) {
					return "http:"+virtualGoodUrlIcon;
				}
				return virtualGoodUrlIcon;
			}
		}

		public string context { get; set; }
		public string contextId { get; set; }
		public DateTime timeStamp { get; set; }
		public int Value { get; set; }
		public Dictionary<string,object> Metadata { get; set;}

		public void Init () {
			Type = RewardType.None;
			switch( GoodId ) {
				case "1":
					Type = RewardType.Coins;
					Value = 5;
					break;

				case "2":
					Type = RewardType.Coins;
					Value = 15;
					break;

				case "3":
					Type = RewardType.Coins;
					Value = 1;
					break;

				default:
					Type = RewardType.None;
					Value = 0;
					break;
			}
		}

		public string PrizeDescription {
			get {
				string result = "";
				switch( Type ) {
					case RewardType.Coins: 
						string localizationKey = (Value == 1 )?"IgniteEventCoins":"IgniteEventCoins";
						result =  Value.ToString();
						break;
					default:
						result =  "";
						break;
				}
				return result;
			}
		}
		
		public void GetReward() {
			switch( Type ) {
				case RewardType.Coins:
					//UserProfileManager.Instance.AddCoins( Value );
					break;
				default:
					break;
			}
		}

		public void RollbackReward() {
			switch( Type ) {
				case RewardType.Coins:
					//UserProfileManager.Instance.AddCoins( -Value );
					break;
				default:
					break;
			}
		}
		
		public static VirtualGoodData ParseFromDictionary ( Dictionary<string,object> virtualGoodDict ) {
			
			VirtualGoodData virtualGoodsData = new VirtualGoodData();
			if( virtualGoodDict.ContainsKey("id") ){
				virtualGoodsData.Id = Convert.ToString( virtualGoodDict["id"] );
			}
			
			if( virtualGoodDict.ContainsKey("goodId") ){
				virtualGoodsData.GoodId = Convert.ToString( virtualGoodDict["goodId"] );
			}
			if( virtualGoodDict.ContainsKey("description") ){
				virtualGoodsData.Description = Convert.ToString( virtualGoodDict["description"] );
			}
			if( virtualGoodDict.ContainsKey("iconUrl") ){
				virtualGoodsData.iconUrl = Convert.ToString( virtualGoodDict["iconUrl"] );
			}
			
			if (virtualGoodDict.ContainsKey ("virtualGoodUrlIcon")) {
				virtualGoodsData.virtualGoodUrlIcon = Convert.ToString (virtualGoodDict ["virtualGoodUrlIcon"]);
			} 

			if (virtualGoodDict.ContainsKey ("context")) {
				virtualGoodsData.context = Convert.ToString (virtualGoodDict ["context"]);
			} 

			if( virtualGoodDict.ContainsKey("context_id") ){
				virtualGoodsData.contextId = Convert.ToString( virtualGoodDict["context_id"] );
			}

			if( virtualGoodDict.ContainsKey("timestamp")){
				DateTime timeStamp = TimeUtility.FromUnixTime (Convert.ToInt64(virtualGoodDict["timestamp"].ToString()));
				virtualGoodsData.timeStamp = timeStamp;
			}

			virtualGoodsData.Metadata = new Dictionary<string,object>();
			if( virtualGoodDict.ContainsKey( "contextMetadata" ) && virtualGoodDict[ "contextMetadata" ].ToString() != "") {
				#if FUEL_SDK
				Dictionary<string,object> dict = FuelSDKCommon.Deserialize (virtualGoodDict[ "contextMetadata" ].ToString()) as Dictionary<string,object>;
				virtualGoodsData.Metadata = dict;
				#endif
			}
			virtualGoodsData.Init();
			return virtualGoodsData;
		}

		public bool TimeStampIsValid {
			get {
				return ( DateTime.Compare (this.timeStamp, TimeUtility.FromUnixTime(0)) != 0 );
			}
		}

		public string ElapsedTimeStampShortString {
			get {
				return TimeUtility.ElapsedTimeString( this.timeStamp );
			}
		}
	}

	public class VirtualGoodLeaderBoardData 
	{
		public VirtualGoodData VirtualGood { get; set; }
		public int Cap { get; set; }
		public float Ratio  { get; set; }
		
		public static VirtualGoodLeaderBoardData ParseFromDictionary ( Dictionary<string,object> virtualGoodLeaderBoardDict ) {
			VirtualGoodLeaderBoardData virtualGoodLeaderBoardData = new VirtualGoodLeaderBoardData();
			virtualGoodLeaderBoardData.VirtualGood = VirtualGoodData.ParseFromDictionary( virtualGoodLeaderBoardDict );
			if( virtualGoodLeaderBoardDict.ContainsKey( "cap" ) ) {
				virtualGoodLeaderBoardData.Cap = Convert.ToInt32( virtualGoodLeaderBoardDict["cap"] );
			}
			if( virtualGoodLeaderBoardDict.ContainsKey( "ratio" ) ) {
				virtualGoodLeaderBoardData.Ratio = (float)Convert.ToDouble( virtualGoodLeaderBoardDict["ratio"] );
			}
			return virtualGoodLeaderBoardData;
		}
	}

}
