﻿using System;
using System.Collections.Generic;

namespace FuelSDKIntegration.Structures 
{
	public class GameMatchData 
	{
		public bool ValidMatchData { get; set; }
		public bool MatchComplete { get; set; }
		public int MatchRound { get; set; }
		public int MatchScore { get; set; }
		public string TournamentID { get; set; }
		public string MatchID { get; set; }
		public string YourNickname { get; set; }

		private string yourAvatarURL { get; set; }
		public string YourAvatarURL
		{ 
			get
			{
				if( !yourAvatarURL.Contains("http:") ) 
				{
					return "http:"+yourAvatarURL;
				}
				return yourAvatarURL;
			}
		}

		public string TheirNickname { get; set; }

		private string theirAvatarURL { get; set; }
		public string TheirAvatarURL
		{ 
			get
			{
				if( !theirAvatarURL.Contains("http:") ) 
				{
					return "http:"+theirAvatarURL;
				}
				return theirAvatarURL;
			}
		}

		public bool AdsAllowed { get; set; }
		public bool FairPlay { get; set; }

		public GameMatchData() {
			this.ValidMatchData = false;
			this.MatchComplete = false;
			this.MatchRound = 0;
			this.MatchScore = 0;
			this.TournamentID = string.Empty;
			this.MatchID = string.Empty;
			this.YourNickname = string.Empty;
			this.yourAvatarURL = string.Empty;
			this.TheirNickname = string.Empty;
			this.theirAvatarURL = string.Empty;
			this.AdsAllowed = false;
			this.FairPlay = false;
		}

		public void ParseFromDictionary ( Dictionary<string,object> gameMatchDict ) {

			this.ValidMatchData = true;

			if( gameMatchDict.ContainsKey( "tournamentID" ) ) {
				this.TournamentID = (string)gameMatchDict ["tournamentID"];
			}

			if( gameMatchDict.ContainsKey( "matchID" ) ) {
				this.MatchID = (string)gameMatchDict ["matchID"];
			}

			if( gameMatchDict.ContainsKey( "params" ) ) {
				Dictionary<string, object> paramsDictionary = gameMatchDict ["params"] as Dictionary<string, object>;

				if (paramsDictionary.ContainsKey ("adsAllowed")) {
					this.AdsAllowed = (bool) paramsDictionary ["adsAllowed"];
				}

				if (paramsDictionary.ContainsKey ("fairPlay")) {
					this.FairPlay = (bool) paramsDictionary ["fairPlay"];
				}

				if (paramsDictionary.ContainsKey ("round")) {
					int round = 0;
					int.TryParse(paramsDictionary ["round"].ToString(),out  round);
					this.MatchRound = round;
				}

				if (paramsDictionary.ContainsKey ("you")) {
					Dictionary<string, object> youDictionary = paramsDictionary ["you"] as Dictionary<string, object>;

					if (youDictionary.ContainsKey ("name")) {
						this.YourNickname = (string)youDictionary ["name"];
					}

					if (youDictionary.ContainsKey ("avatar")) {
						this.yourAvatarURL = (string)youDictionary ["avatar"];
					}
				}

				if (paramsDictionary.ContainsKey ("them")) {
					Dictionary<string, object> themDictionary = paramsDictionary ["them"] as Dictionary<string, object>;

					if (themDictionary.ContainsKey ("name")) {
						this.TheirNickname = (string)themDictionary ["name"];
					}

					if (themDictionary.ContainsKey ("avatar")) {
						this.theirAvatarURL = (string)themDictionary ["avatar"];
					}
				}
			}

			this.MatchComplete = false;
		}
	}

}