using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

namespace FuelSDKIntegration.Structures 
{	
	public class IgniteLeaderBoard : IgniteActivity 
	{
		public string CurrentUserId { get; set; }
		public List<LeaderData> Leaders { get; set; }
		public LeaderBoardRuleData Rule { get; set; }
		public LeaderBoardMetadata Metadata { get; set; }
		public LeaderBoardVisualData VisualData { get; set; }

		public IgniteLeaderBoard() {
			this.Leaders = new List<LeaderData>();
			this.Rule = new LeaderBoardRuleData();
			this.Metadata = new LeaderBoardMetadata();
			this.VisualData = new LeaderBoardVisualData( string.Empty );
		}

		public override void Create( Dictionary<string,object> dataDict ) {
			base.Create( dataDict );
			if( dataDict.ContainsKey( "currentUserId" ) ) {
				this.CurrentUserId = Convert.ToString( dataDict["currentUserId"] );
			}
			
			if( dataDict.ContainsKey( "rule" ) ) {
				Dictionary<string,object> leaderBoardRuleDict = dataDict["rule"] as Dictionary<string,object>;
				this.Rule = LeaderBoardRuleData.ParseFromDictionary( leaderBoardRuleDict );
			}

			this.Leaders = new List<LeaderData>();
			if( dataDict.ContainsKey( "leaderList" ) ) {
				Dictionary<string,object> leaderListDict = dataDict["leaderList"] as Dictionary<string,object>;
				if( leaderListDict.ContainsKey( "leaders" ) ) {
					List<object> leaderList = leaderListDict["leaders"] as List<object>;
					int position = 1;
					foreach( object leaderObject in leaderList ) {
						Dictionary<string,object> leaderDict = leaderObject as Dictionary<string,object>;
						LeaderData leaderData = LeaderData.ParseFromDictionary( leaderDict );
						if( this.CurrentUserId == leaderData.Id ) {
							leaderData.IsCurrentUser = true;
						}
						leaderData.Rank = position;
						this.Leaders.Add( leaderData );
						position++;
					}
				}
			}

			if( dataDict.ContainsKey( "metadata" ) ) {
				Dictionary<string,object> metadataDict = dataDict["metadata"] as Dictionary<string,object>;
				this.Metadata = new LeaderBoardMetadata();
				this.Metadata.Create( metadataDict );
			}

			this.VisualData = new LeaderBoardVisualData( this.Id );
		}

		public override bool GetVirtualGood () {
			if( !string.IsNullOrEmpty( this.Metadata.participationVirtualGood.Id ) ) {
				this.Metadata.participationVirtualGood.GetReward();
				return true;
			}
			return base.GetVirtualGood();
		}

		public override bool HaveVirtualGood () {
			if( !string.IsNullOrEmpty( this.Metadata.participationVirtualGood.Id ) ) {
				return true;
			}
			if( this.Metadata.VirtualGoodList.Count > 0 ) {
				return true;
			}
			return base.HaveVirtualGood();
		}

		public override bool HasParticipated() {
			if( this.Leaders.Count > 0 ) {
				return true;
			}
			return false;
		}

	}

	public struct LeaderBoardRuleData 
	{
		public string Id { get; set; }
		public string Variable { get; set; }
		public int Kind { get; set; }
		public int Score { get; set; }
		
		public static LeaderBoardRuleData ParseFromDictionary ( Dictionary<string,object> leaderBoardRuleDict ) {
			LeaderBoardRuleData leaderBoardRuleData = new LeaderBoardRuleData();
			if( leaderBoardRuleDict.ContainsKey("id") ){
				leaderBoardRuleData.Id = Convert.ToString( leaderBoardRuleDict["id"] );
			}
			if( leaderBoardRuleDict.ContainsKey("variable") ){
				leaderBoardRuleData.Variable = Convert.ToString( leaderBoardRuleDict["variable"] );
			}
			if( leaderBoardRuleDict.ContainsKey("kind") ){
				leaderBoardRuleData.Kind = Convert.ToInt32( leaderBoardRuleDict["kind"] );
			}
			if( leaderBoardRuleDict.ContainsKey("score") ){
				leaderBoardRuleData.Score = Convert.ToInt32( leaderBoardRuleDict["score"] );
			}
			return leaderBoardRuleData;
		}
	}

	public class LeaderData 
	{
		public string Id { get; set; }
		public bool IsCurrentUser { get; set; }
		public string Name { get; set; }
		public int Score { get; set; }
		public int Rank { get; set; }
		
		public static LeaderData ParseFromDictionary ( Dictionary<string,object> leaderDict ) {
			LeaderData leaderData = new LeaderData();
			if( leaderDict.ContainsKey("id") ){
				leaderData.Id = Convert.ToString( leaderDict["id"] );
			}
			if( leaderDict.ContainsKey("name") ){
				leaderData.Name = Convert.ToString( leaderDict["name"] );
			}
			if( leaderDict.ContainsKey("score") ){
				leaderData.Score = Convert.ToInt32( leaderDict["score"] );
			}
			if( leaderDict.ContainsKey("rank") ){
				leaderData.Rank = Convert.ToInt32( leaderDict["rank"] );
			}
			return leaderData;
		}
	}

	public class LeaderBoardMetadata:IgniteActivityMetadata 
	{
		public string GameData { get; set; }
		public List<VirtualGoodLeaderBoardData> VirtualGoodList;
		public VirtualGoodData participationVirtualGood { get; set; }

		public LeaderBoardMetadata() {
			this.participationVirtualGood = new VirtualGoodData();
			this.VirtualGoodList = new List<VirtualGoodLeaderBoardData>();
		}

		public override void Create ( Dictionary<string,object> metadataDict ) {
			base.Create( metadataDict );

			if( metadataDict.ContainsKey( "gamedata" ) ) {
				this.GameData = Convert.ToString( metadataDict["gamedata"] );
			}
				
			if( metadataDict.ContainsKey( "virtualGoods" ) ) {
				List<VirtualGoodLeaderBoardData> virtualGoodList = new List<VirtualGoodLeaderBoardData>();
				List<object> virtualGoodListObjects = metadataDict["virtualGoods"] as List<object>;
				foreach( object virtualGoodObject in virtualGoodListObjects ) {
					Dictionary<string,object> virtualGoodObjectDict = virtualGoodObject as Dictionary<string,object>;
					VirtualGoodLeaderBoardData virtualGoodLeaderBoardData = VirtualGoodLeaderBoardData.ParseFromDictionary( virtualGoodObjectDict );
					virtualGoodList.Add( virtualGoodLeaderBoardData );
				}
				this.VirtualGoodList = virtualGoodList;
			}



			if( metadataDict.ContainsKey( "participationVirtualGood" ) && !String.IsNullOrEmpty(metadataDict["participationVirtualGood"].ToString())) {
				VirtualGoodData virtualGood = new VirtualGoodData();
				Dictionary<string,object> virtualGoodDict = metadataDict["participationVirtualGood"] as Dictionary<string,object>;
				if( virtualGoodDict.ContainsKey( "iconUrl" ) ) {
					virtualGood.iconUrl = Convert.ToString( virtualGoodDict["iconUrl"]);
				}
				if( virtualGoodDict.ContainsKey( "description" ) ) {
					virtualGood.Description = Convert.ToString( virtualGoodDict["description"] );
				}
				if( virtualGoodDict.ContainsKey( "id" ) ) {
					virtualGood.Id = Convert.ToString( virtualGoodDict["id"] );
				}
				if( virtualGoodDict.ContainsKey( "goodId" ) ) {
					virtualGood.GoodId = Convert.ToString( virtualGoodDict["goodId"] );
				}
				virtualGood.Init();

				this.participationVirtualGood = virtualGood;
			}
		}

	}

	public class LeaderBoardVisualData : VisualData 
	{
		public LeaderBoardVisualData( string id ) : base ( id ) {
		}

		private const string prefLastRank = "IgniteLeaderBoardLastRank_";
		public int LastRank { 
			get {
				return base.GetIntValue( prefLastRank );
			}
			set {
				base.SetIntValue( prefLastRank, value );
			}
		}

		private const string prefLastScore = "IgniteLeaderBoardLastScore_";
		public float LastScore { 
			get {
				return base.GetFloatValue( prefLastScore );
			}
			set {
				base.SetFloatValue( prefLastScore, value );
			}
		}
	}
}