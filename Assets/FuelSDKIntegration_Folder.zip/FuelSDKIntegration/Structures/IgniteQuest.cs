using System;
using System.Collections;

namespace FuelSDKIntegration.Structures 
{
	public class IgniteQuest : IgniteActivity 
	{

	}

}
